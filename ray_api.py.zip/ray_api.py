import logging
import os
import random
import tempfile
from collections import defaultdict
from typing import Dict, List

import ray
from ray import serve
from starlette.requests import Request
from fastapi import FastAPI, Request, File, UploadFile, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import uvicorn
from surya.detection import batch_text_detection
from surya.input.langs import replace_lang_with_code, get_unique_langs
from surya.input.load import load_from_file
from surya.layout import batch_layout_detection
from surya.model.detection import segformer
from surya.model.ordering.model import load_model as load_order_mode
from surya.model.ordering.processor import load_processor as load_order_processor
from surya.model.recognition.model import load_model as load_recognition_model
from surya.model.recognition.processor import load_processor as load_recognition_processor
from surya.model.recognition.tokenizer import _tokenize
from surya.ocr import run_ocr
from surya.ordering import batch_ordering
from surya.settings import settings
from werkzeug.utils import secure_filename

app = FastAPI()
# ray.init(address='auto')
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
temp_dir = tempfile.gettempdir()


class PredictResponse(BaseModel):
    prediction: Dict


@app.exception_handler(Exception)
async def handle_exception(request: Request, exc: Exception):
    logger.error(f"An error occurred: {exc}")
    return JSONResponse(
        status_code=500,
        content={"message": "An unexpected error occurred. Please try again later."},
    )


@serve.deployment(ray_actor_options={"num_gpus": 1}, num_replicas=4)
@serve.ingress(app)
class SuryaApi:
    def __init__(self):
        self.layout_model = ray.put(segformer.load_model(checkpoint=settings.LAYOUT_MODEL_CHECKPOINT, device="cuda"))
        self.layout_processor = ray.put(segformer.load_processor(checkpoint=settings.LAYOUT_MODEL_CHECKPOINT))
        self.det_model = ray.put(segformer.load_model(device="cuda"))
        self.det_processor = ray.put(segformer.load_processor())
        self.order_model = ray.put(load_order_mode(device="cuda"))
        self.order_prcessor = ray.put(load_order_processor())

    @app.post("/api/analyze_layout", response_model=Dict[str, List[Dict]])
    async def analyze_layout(self, file: UploadFile = File(...)):
        try:
            filename = secure_filename(file.filename)
            temp_file_path = os.path.join(temp_dir, "layout_" + str(random.randint(1, 10000)) + "_" + filename)
            with open(temp_file_path, "wb") as f:
                f.write(await file.read())
            results = {}

            images, names = load_from_file(temp_file_path)
            line_predictions = batch_text_detection(images, ray.get(self.det_model), ray.get(self.det_processor))
            layout_predictions = batch_layout_detection(images, ray.get(self.layout_model),
                                                        ray.get(self.layout_processor), line_predictions)

            predictions_by_page = defaultdict(list)
            for idx, (pred, name, image) in enumerate(zip(layout_predictions, names, images)):
                out_pred = pred.model_dump(exclude=["segmentation_map"])
                out_pred["page"] = len(predictions_by_page[name]) + 1
                predictions_by_page[name].append(out_pred)

            results[filename] = layout_predictions
            return predictions_by_page
        except Exception as e:
            logger.info("layout_analyze error,", e)
            raise HTTPException(status_code=500, detail="Internal Server Error")

    @app.post("/api/ocr", response_model=Dict[str, List[Dict]])
    async def ocr_task(self, file: UploadFile = File(...), langs: str = "en") -> Dict:
        try:
            langs = langs.split(',')
            filename = secure_filename(file.filename)
            file_path = os.path.join(temp_dir, "ocr_" + filename)
            with open(file_path, "wb") as f:
                f.write(await file.read())
            images, names = load_from_file(file_path)
            replace_lang_with_code(langs)
            image_langs = [langs] * len(images)

            _, lang_tokens = _tokenize("", get_unique_langs(image_langs))
            rec_model = load_recognition_model(langs=lang_tokens, device="cuda")
            rec_processor = load_recognition_processor()

            predictions_by_image = run_ocr(images, image_langs, ray.get(self.det_model), ray.get(self.det_processor),
                                           rec_model,
                                           rec_processor,
                                           32)

            out_preds = defaultdict(list)
            for name, pred, image in zip(names, predictions_by_image, images):
                out_pred = pred.model_dump()
                out_pred["page"] = len(out_preds[name]) + 1
                out_preds[name].append(out_pred)
            return out_preds
        except Exception as e:
            raise HTTPException(status_code=500, detail="Internal Server Error")

    @app.post("/api/detect", response_model=Dict[str, List[Dict]])
    async def text_detect(self, file: UploadFile = File(...)):
        try:
            filename = secure_filename(file.filename)
            file_path = os.path.join(temp_dir, "detect_" + filename)
            with open(file_path, "wb") as f:
                f.write(await file.read())
            images, names = load_from_file(file_path, 1000)
            predictions = batch_text_detection(images, ray.get(self.det_model), ray.get(self.det_processor))
            predictions_by_page = defaultdict(list)
            for idx, (pred, name, image) in enumerate(zip(predictions, names, images)):
                out_pred = pred.model_dump(exclude=["heatmap", "affinity_map"])
                out_pred["page"] = len(predictions_by_page[name]) + 1
                predictions_by_page[name].append(out_pred)
            return predictions_by_page
        except Exception as e:
            raise HTTPException(status_code=500, detail="Internal Server Error")

    @app.post("/api/read_order", response_model=Dict[str, List[Dict]])
    async def read_order(self, file: UploadFile = File(...)):
        try:
            filename = secure_filename(file.filename)
            file_path = os.path.join(temp_dir, "detect_" + filename)
            with open(file_path, "wb") as f:
                f.write(await file.read())
            images, names = load_from_file(file_path, 1000)
            line_predictions = batch_text_detection(images, ray.get(self.det_model), ray.get(self.det_processor))
            layout_predictions = batch_layout_detection(images, ray.get(self.layout_model),
                                                        ray.get(self.layout_processor),
                                                        line_predictions)
            bboxes = []
            for layout_pred in layout_predictions:
                bbox = [l.bbox for l in layout_pred.bboxes]
                bboxes.append(bbox)

            order_predictions = batch_ordering(images, bboxes, ray.get(self.order_model), ray.get(self.order_prcessor))
            predictions_by_page = defaultdict(list)
            for idx, (layout_pred, pred, name, image) in enumerate(
                    zip(layout_predictions, order_predictions, names, images)):
                out_pred = pred.model_dump()
                for bbox, layout_bbox in zip(out_pred["bboxes"], layout_pred.bboxes):
                    bbox["label"] = layout_bbox.label

                out_pred["page"] = len(predictions_by_page[name]) + 1
                predictions_by_page[name].append(out_pred)

            for name in predictions_by_page:
                for page_preds in predictions_by_page[name]:
                    page_preds["bboxes"] = sorted(page_preds["bboxes"], key=lambda x: x["position"])

            return predictions_by_page
        except Exception as e:
            raise HTTPException(status_code=500, detail="Internal Server Error")


app = SuryaApi.bind()
